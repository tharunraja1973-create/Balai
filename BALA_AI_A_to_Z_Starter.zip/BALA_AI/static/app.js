const state = { provider: "openai", compare: false, busy: false };
const names = { openai: "ChatGPT", claude: "Claude", gemini: "Gemini" };
const welcome = document.getElementById("welcome");
const messages = document.getElementById("messages");
const promptBox = document.getElementById("prompt");
const sendBtn = document.getElementById("sendBtn");
const modeLabel = document.getElementById("modeLabel");

function setMode() {
  document.querySelectorAll(".model-choice").forEach(b => b.classList.toggle("active", b.dataset.provider === state.provider));
  document.getElementById("compareToggle").classList.toggle("active", state.compare);
  modeLabel.textContent = state.compare ? "Comparing ChatGPT + Claude + Gemini" : `Using ${names[state.provider]}`;
}
document.querySelectorAll(".model-choice").forEach(b => b.addEventListener("click", () => {
  state.provider = b.dataset.provider; state.compare = false; setMode();
}));
document.getElementById("compareToggle").addEventListener("click", () => {
  state.compare = !state.compare; setMode();
});
document.getElementById("newChat").addEventListener("click", () => {
  messages.innerHTML = ""; messages.style.display = "none"; welcome.style.display = ""; promptBox.value = "";
});
document.querySelectorAll("[data-prompt]").forEach(b => b.addEventListener("click", () => {
  promptBox.value = b.dataset.prompt; promptBox.focus(); resizeInput();
}));
promptBox.addEventListener("input", resizeInput);
promptBox.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); document.getElementById("chatForm").requestSubmit(); }
});
function resizeInput() { promptBox.style.height = "auto"; promptBox.style.height = Math.min(promptBox.scrollHeight, 190) + "px"; }
function addMessage(role, text, error=false) {
  const row = document.createElement("div");
  row.className = `message ${role}${error ? " error" : ""}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "user" ? "You" : "B";
  const body = document.createElement("div");
  const label = document.createElement("div"); label.className = "role"; label.textContent = role === "user" ? "You" : "BALA AI";
  const content = document.createElement("div"); content.className = "content"; content.textContent = text;
  body.append(label, content); row.append(avatar, body); messages.append(row);
  return content;
}
function addCompare(results) {
  const row = document.createElement("div"); row.className = "message assistant";
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = "B";
  const body = document.createElement("div"); const label = document.createElement("div"); label.className = "role"; label.textContent = "THREE-AI COMPARISON";
  const grid = document.createElement("div"); grid.className = "compare-grid";
  results.forEach(result => {
    const card = document.createElement("section"); card.className = "compare-card";
    const title = document.createElement("h3"); title.textContent = names[result.provider] || result.provider;
    const p = document.createElement("p"); p.textContent = result.answer; if (!result.ok) p.className = "error-text";
    card.append(title, p); grid.append(card);
  });
  body.append(label, grid); row.append(avatar, body); messages.append(row);
}
function showChat() { welcome.style.display = "none"; messages.style.display = "block"; }
async function submitMessage(message) {
  if (!message || state.busy) return;
  state.busy = true; sendBtn.disabled = true;
  showChat(); addMessage("user", message);
  const loading = addMessage("assistant", state.compare ? "Asking all three AI models…" : `Asking ${names[state.provider]}…`);
  promptBox.value = ""; resizeInput();
  try {
    const endpoint = state.compare ? "/api/compare" : "/api/chat";
    const payload = state.compare ? {message} : {message, provider: state.provider};
    const response = await fetch(endpoint, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)});
    const data = await response.json();
    loading.parentElement.parentElement.remove();
    if (!response.ok) {
      const detail = data.detail || "Something went wrong.";
      addMessage("assistant", detail, true);
    } else if (state.compare) {
      addCompare(data.results || []);
    } else {
      addMessage("assistant", data.answer || "No response received.");
    }
  } catch (err) {
    loading.textContent = "Cannot connect to the server. Make sure BALA AI is running.";
    loading.parentElement.parentElement.classList.add("error");
  } finally {
    state.busy = false; sendBtn.disabled = false; promptBox.focus();
    window.scrollTo({top:document.body.scrollHeight, behavior:"smooth"});
  }
}
document.getElementById("chatForm").addEventListener("submit", e => {
  e.preventDefault(); submitMessage(promptBox.value.trim());
});
async function checkHealth() {
  try {
    const r = await fetch("/api/health"); const data = await r.json();
    const configured = data.configured || {};
    const count = Object.values(configured).filter(Boolean).length;
    const status = document.getElementById("statusText");
    status.textContent = `${count}/3 AI APIs configured`;
    status.previousElementSibling.style.background = count === 3 ? "#42d6a4" : "#e3b65a";
  } catch { document.getElementById("statusText").textContent = "Server status unavailable"; }
}
setMode(); checkHealth();
